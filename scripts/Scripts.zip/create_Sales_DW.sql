DROP DATABASE IF EXISTS sales_dw;
CREATE DATABASE sales_dw;
USE sales_dw;